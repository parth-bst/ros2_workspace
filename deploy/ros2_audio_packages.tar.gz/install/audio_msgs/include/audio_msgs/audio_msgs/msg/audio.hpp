// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef AUDIO_MSGS__MSG__AUDIO_HPP_
#define AUDIO_MSGS__MSG__AUDIO_HPP_

#include "audio_msgs/msg/detail/audio__struct.hpp"
#include "audio_msgs/msg/detail/audio__builder.hpp"
#include "audio_msgs/msg/detail/audio__traits.hpp"
#include "audio_msgs/msg/detail/audio__type_support.hpp"

#endif  // AUDIO_MSGS__MSG__AUDIO_HPP_
