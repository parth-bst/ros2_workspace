// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from audio_msgs:msg/Audio.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "audio_msgs/msg/audio.hpp"


#ifndef AUDIO_MSGS__MSG__DETAIL__AUDIO__BUILDER_HPP_
#define AUDIO_MSGS__MSG__DETAIL__AUDIO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "audio_msgs/msg/detail/audio__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace audio_msgs
{

namespace msg
{

namespace builder
{

class Init_Audio_data
{
public:
  explicit Init_Audio_data(::audio_msgs::msg::Audio & msg)
  : msg_(msg)
  {}
  ::audio_msgs::msg::Audio data(::audio_msgs::msg::Audio::_data_type arg)
  {
    msg_.data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::audio_msgs::msg::Audio msg_;
};

class Init_Audio_coding_format
{
public:
  explicit Init_Audio_coding_format(::audio_msgs::msg::Audio & msg)
  : msg_(msg)
  {}
  Init_Audio_data coding_format(::audio_msgs::msg::Audio::_coding_format_type arg)
  {
    msg_.coding_format = std::move(arg);
    return Init_Audio_data(msg_);
  }

private:
  ::audio_msgs::msg::Audio msg_;
};

class Init_Audio_bitrate
{
public:
  explicit Init_Audio_bitrate(::audio_msgs::msg::Audio & msg)
  : msg_(msg)
  {}
  Init_Audio_coding_format bitrate(::audio_msgs::msg::Audio::_bitrate_type arg)
  {
    msg_.bitrate = std::move(arg);
    return Init_Audio_coding_format(msg_);
  }

private:
  ::audio_msgs::msg::Audio msg_;
};

class Init_Audio_sample_format
{
public:
  explicit Init_Audio_sample_format(::audio_msgs::msg::Audio & msg)
  : msg_(msg)
  {}
  Init_Audio_bitrate sample_format(::audio_msgs::msg::Audio::_sample_format_type arg)
  {
    msg_.sample_format = std::move(arg);
    return Init_Audio_bitrate(msg_);
  }

private:
  ::audio_msgs::msg::Audio msg_;
};

class Init_Audio_channels
{
public:
  explicit Init_Audio_channels(::audio_msgs::msg::Audio & msg)
  : msg_(msg)
  {}
  Init_Audio_sample_format channels(::audio_msgs::msg::Audio::_channels_type arg)
  {
    msg_.channels = std::move(arg);
    return Init_Audio_sample_format(msg_);
  }

private:
  ::audio_msgs::msg::Audio msg_;
};

class Init_Audio_sample_rate
{
public:
  explicit Init_Audio_sample_rate(::audio_msgs::msg::Audio & msg)
  : msg_(msg)
  {}
  Init_Audio_channels sample_rate(::audio_msgs::msg::Audio::_sample_rate_type arg)
  {
    msg_.sample_rate = std::move(arg);
    return Init_Audio_channels(msg_);
  }

private:
  ::audio_msgs::msg::Audio msg_;
};

class Init_Audio_header
{
public:
  Init_Audio_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Audio_sample_rate header(::audio_msgs::msg::Audio::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Audio_sample_rate(msg_);
  }

private:
  ::audio_msgs::msg::Audio msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::audio_msgs::msg::Audio>()
{
  return audio_msgs::msg::builder::Init_Audio_header();
}

}  // namespace audio_msgs

#endif  // AUDIO_MSGS__MSG__DETAIL__AUDIO__BUILDER_HPP_
