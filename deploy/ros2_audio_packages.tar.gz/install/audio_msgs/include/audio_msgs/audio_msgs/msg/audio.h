// generated from rosidl_generator_c/resource/idl.h.em
// with input from audio_msgs:msg/Audio.idl
// generated code does not contain a copyright notice

#ifndef AUDIO_MSGS__MSG__AUDIO_H_
#define AUDIO_MSGS__MSG__AUDIO_H_

#include "audio_msgs/msg/detail/audio__struct.h"
#include "audio_msgs/msg/detail/audio__functions.h"
#include "audio_msgs/msg/detail/audio__type_support.h"

#endif  // AUDIO_MSGS__MSG__AUDIO_H_
